<<<<<<< HEAD
# Reddit User Persona Generator

This project scrapes a Reddit user's posts and comments, then generates a basic user persona.

## 🔧 Setup Instructions

1. Clone this repository.
2. Create a `.env` file using the provided `.env.example` format.
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Run the script:
   ```
   python main.py
   ```

## 📁 Output
Creates a `txt` file with the user's persona and cited posts/comments.

## 🔑 Reddit API Credentials
- Get your credentials from [Reddit Apps](https://www.reddit.com/prefs/apps).
=======
# reddit_persona_generator
>>>>>>> 75c9f593f8b74c065320e4e7ac2262a06b38202c
