def build_persona(reddit, username):
    user = reddit.redditor(username)
    persona = f"👤 Qualitative Persona for Reddit User: u/{username}\n"
    persona += "=" * 60 + "\n\n"

    posts = []
    comments = []

    try:
        for post in user.submissions.new(limit=50):
            posts.append({
                "title": post.title,
                "subreddit": str(post.subreddit),
                "url": post.url,
                "permalink": f"https://www.reddit.com{post.permalink}"
            })
    except Exception as e:
        print("Error fetching posts:", e)

    try:
        for comment in user.comments.new(limit=50):
            comments.append({
                "body": comment.body,
                "subreddit": str(comment.subreddit),
                "permalink": f"https://www.reddit.com{comment.permalink}"
            })
    except Exception as e:
        print("Error fetching comments:", e)

    # Heuristic Analysis
    subreddits = list(set([p['subreddit'] for p in posts + comments]))
    interests = ", ".join(subreddits[:5])  # limit to top 5
    total_posts = len(posts)
    total_comments = len(comments)

    sample_comment = comments[0] if comments else {"body": "N/A", "permalink": "#"}
    sample_post = posts[0] if posts else {"title": "N/A", "permalink": "#"}

    # ✍️ Persona Format (Based on Image)
    persona += f"🧠 Personality Traits:\n- Curious\n- Opinionated\n- Engaged in online communities\n\n"
    persona += f"💬 Quote:\n\"{sample_comment['body'][:120]}...\"\n(Source: {sample_comment['permalink']})\n\n"
    persona += f"📍 Demographics:\n- Location: Unknown\n- Age: Unknown\n- Gender: Unknown\n\n"
    persona += f"🎯 Goals:\n- To share thoughts, learn from others, and engage in specific subreddit discussions\n\n"
    persona += f"😤 Frustrations:\n- May get annoyed by misinformation or trolling\n\n"
    persona += f"📱 Tech Use:\n- Active Reddit user\n- Possibly uses desktop/mobile interchangeably\n\n"
    persona += f"🏷️ Favorite Subreddits (Interests):\n- {interests}\n\n"
    persona += f"🔗 Sample Post:\n\"{sample_post['title']}\"\n(Source: {sample_post['permalink']})\n\n"
    persona += f"📊 Activity Summary:\n- Total Posts Scraped: {total_posts}\n- Total Comments Scraped: {total_comments}\n\n"
    persona += "=" * 60 + "\n"

    return persona