import os
import praw
from dotenv import load_dotenv
from persona_builder import build_persona

def main():
    load_dotenv()
    reddit = praw.Reddit(
        client_id=os.getenv("REDDIT_CLIENT_ID"),
        client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
        user_agent=os.getenv("REDDIT_USER_AGENT")
    )

    username = input("Enter the Reddit username (e.g., kojied): ").strip()
    persona_text = build_persona(reddit, username)

    output_file = f"output_user_{username}.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(persona_text)

    print(f"User persona saved to {output_file}")

if __name__ == "__main__":
    main()
