import praw
import openai
import os
from dotenv import load_dotenv

load_dotenv()

reddit = praw.Reddit(
    client_id=os.getenv("REDDIT_CLIENT_ID"),
    client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
    user_agent=os.getenv("REDDIT_USER_AGENT")
)

openai.api_key = os.getenv("OPENAI_API_KEY")

def reddit_profile_to_username(url):
    return url.strip("/").split("/")[-1]

def fetch_user_data(username, post_limit=50, comment_limit=50):
    user = reddit.redditor(username)
    posts, comments = [], []
    for submission in user.submissions.new(limit=post_limit):
        posts.append({
            "title": submission.title,
            "selftext": submission.selftext,
            "subreddit": submission.subreddit.display_name,
            "url": submission.url,
            "permalink": f"https://www.reddit.com{submission.permalink}"
        })
    for comment in user.comments.new(limit=comment_limit):
        comments.append({
            "body": comment.body,
            "subreddit": comment.subreddit.display_name,
            "permalink": f"https://www.reddit.com{comment.permalink}"
        })
    return posts, comments

def generate_persona(posts, comments):
    combined = "\n\n".join(
        [f"POST: {p['title']} - {p['selftext']}" for p in posts] +
        [f"COMMENT: {c['body']}" for c in comments]
    )
    prompt = f"""You are an expert at building user personas.

Given the following Reddit posts and comments, generate a detailed user persona.
Include:
- Name (fictional)
- Age (estimated)
- Occupation
- Interests
- Personality Traits
- Values
- Communication Style
- Subreddits they are active on

For each trait, include which post or comment (quoted) helped you decide.

Text:
{combined}
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

def save_to_file(content, username):
    filename = f"{username}_persona.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"Persona saved to {filename}")

def main():
    url = input("Enter Reddit profile URL: ")
    username = reddit_profile_to_username(url)
    print(f"Fetching data for u/{username}...")
    posts, comments = fetch_user_data(username)
    print("Generating user persona...")
    persona = generate_persona(posts, comments)
    save_to_file(persona, username)

if __name__ == "__main__":
    main()
