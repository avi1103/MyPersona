# Reddit User Persona Generator

## Setup Instructions

1. **Install dependencies:**
```bash
pip install -r requirements.txt
```

2. **Set up environment variables:**
- Copy `.env.example` to `.env`
- Fill in your Reddit and OpenAI API credentials

3. **Run the script:**
```bash
python main.py
```

Enter a Reddit profile URL when prompted. The script will fetch the user's posts and comments, generate a persona using GPT, and save it to a text file.
